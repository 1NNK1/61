const users = [
  { id: 1, username: 'olena', password: 'admin123', name: 'Олена Коваль', role: 'admin', city: 'Київ' },
  { id: 2, username: 'andrii', password: 'user123', name: 'Андрій Шевченко', role: 'user', city: 'Львів' },
  { id: 3, username: 'maria', password: 'user123', name: 'Марія Бойко', role: 'user', city: 'Одеса' }
];

const findAll = () => users;
const findById = (id) => users.find((u) => u.id === id);
const findByCredentials = (username, password) =>
  users.find((u) => u.username === username && u.password === password);

module.exports = { findAll, findById, findByCredentials };
