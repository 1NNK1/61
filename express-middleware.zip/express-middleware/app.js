const express = require('express');
const logger = require('./middleware/logger');
const textResponse = require('./middleware/textResponse');
const sessionMiddleware = require('./middleware/session');
const { notFound, errorHandler } = require('./middleware/errorHandler');

const app = express();

app.use(logger);
app.use(textResponse);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(sessionMiddleware);

app.use('/', require('./routes/index'));
app.use('/', require('./routes/auth'));
app.use('/users', require('./routes/users'));
app.use('/articles', require('./routes/articles'));

app.use(notFound);
app.use(errorHandler);

if (require.main === module) {
  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => console.log(`Server: http://localhost:${PORT}`));
}

module.exports = app;
