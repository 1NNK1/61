const notFound = (req, res) => {
  res.status(404).send('Сторінку не знайдено');
};

const errorHandler = (err, req, res, next) => {
  if (res.headersSent) {
    return next(err);
  }
  if (err.type === 'entity.parse.failed') {
    return res.status(400).send('Помилка: некоректний JSON');
  }
  const status = err.status || err.statusCode || 500;
  console.error(err.message);
  res.status(status).send(status === 500 ? 'Внутрішня помилка сервера' : `Помилка: ${err.message}`);
};

module.exports = { notFound, errorHandler };
