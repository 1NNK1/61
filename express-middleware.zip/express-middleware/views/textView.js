const home = (user) =>
  `Сервер працює.\nПоточний користувач: ${user ? `${user.username} (${user.role})` : 'гість'}`;

const userLine = (u) => `${u.id}. ${u.name} — ${u.role}, ${u.city}`;

const userList = (users) => `Користувачі:\n${users.map(userLine).join('\n')}`;

const user = (u) =>
  `Користувач #${u.id}\nІм'я: ${u.name}\nЛогін: ${u.username}\nРоль: ${u.role}\nМісто: ${u.city}`;

const articleList = (articles) =>
  articles.length
    ? `Статті:\n${articles.map((a) => `${a.id}. ${a.title} [${a.visibility}]`).join('\n')}`
    : 'Статей немає';

const article = (a) => `${a.title}\nДоступ: ${a.visibility}\n\n${a.content}`;

module.exports = { home, userList, user, articleList, article };
