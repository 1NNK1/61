const Article = require('../models/articleModel');

module.exports = (req, res, next) => {
  const article = Article.findById(Number(req.params.articleId));
  if (!article) {
    return res.status(404).send('Статтю не знайдено');
  }
  const user = req.session.user;
  if (!Article.canView(article, user)) {
    if (!user) {
      return res.status(401).send('Ця стаття приватна. Виконайте POST /login');
    }
    return res.status(403).send('Доступ заборонено: ви не маєте прав на цю статтю');
  }
  req.article = article;
  next();
};
