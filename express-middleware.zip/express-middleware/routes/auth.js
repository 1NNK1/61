const express = require('express');
const auth = require('../controllers/authController');
const { validateLogin } = require('../middleware/validate');

const router = express.Router();

router.post('/login', validateLogin, auth.login);
router.post('/logout', auth.logout);

module.exports = router;
