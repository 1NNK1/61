const isPositiveInt = (value) => /^[1-9]\d*$/.test(String(value));

const validateId = (param) => (req, res, next) => {
  if (!isPositiveInt(req.params[param])) {
    return res.status(400).send(`Некоректний ${param}: потрібне додатне ціле число`);
  }
  next();
};

const validateListQuery = (req, res, next) => {
  if (req.query.limit !== undefined && !isPositiveInt(req.query.limit)) {
    return res.status(400).send('Некоректний limit: потрібне додатне ціле число');
  }
  next();
};

const validateLogin = (req, res, next) => {
  const { username, password } = req.body || {};
  const valid = (v) => typeof v === 'string' && v.trim().length > 0;
  if (!valid(username) || !valid(password)) {
    return res.status(400).send('Потрібні поля username і password (непорожні рядки)');
  }
  next();
};

module.exports = { validateId, validateListQuery, validateLogin };
