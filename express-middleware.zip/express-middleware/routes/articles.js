const express = require('express');
const articles = require('../controllers/articleController');
const checkArticleAccess = require('../middleware/access');
const { validateId } = require('../middleware/validate');

const router = express.Router();

router.get('/', articles.list);
router.get('/:articleId', validateId('articleId'), checkArticleAccess, articles.details);

module.exports = router;
