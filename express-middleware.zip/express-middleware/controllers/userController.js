const User = require('../models/userModel');
const view = require('../views/textView');

exports.list = (req, res) => {
  const all = User.findAll();
  const users = req.query.limit ? all.slice(0, Number(req.query.limit)) : all;
  res.send(view.userList(users));
};

exports.details = (req, res) => {
  const found = User.findById(Number(req.params.userId));
  if (!found) {
    return res.status(404).send('Користувача не знайдено');
  }
  res.send(view.user(found));
};
