const app = require('./app');

const checks = [
  ['GET', '/', null, 200, 'головна без входу'],
  ['GET', '/users', null, 401, '/users без входу'],
  ['GET', '/users/1', null, 401, '/users/1 без входу'],
  ['GET', '/articles', null, 200, 'список статей для гостя'],
  ['GET', '/articles/1', null, 200, 'публічна стаття'],
  ['GET', '/articles/3', null, 401, 'приватна стаття без входу'],
  ['GET', '/articles/abc', null, 400, 'некоректний articleId'],
  ['POST', '/login', {}, 400, 'вхід без даних'],
  ['POST', '/login', { username: 'andrii', password: 'wrong' }, 401, 'неправильний пароль'],
  ['POST', '/login', { username: 'andrii', password: 'user123' }, 200, 'успішний вхід'],
  ['GET', '/users', null, 200, '/users після входу'],
  ['GET', '/users?limit=abc', null, 400, 'некоректний limit'],
  ['GET', '/users/abc', null, 400, 'некоректний userId'],
  ['GET', '/users/99', null, 404, 'неіснуючий користувач'],
  ['GET', '/users/2', null, 200, 'існуючий користувач'],
  ['GET', '/articles/3', null, 403, 'чужа приватна стаття'],
  ['GET', '/articles/4', null, 200, 'власна приватна стаття'],
  ['POST', '/logout', null, 200, 'вихід'],
  ['GET', '/users', null, 401, '/users після виходу'],
  ['GET', '/nope', null, 404, 'неіснуючий маршрут']
];

const server = app.listen(0, async () => {
  const base = `http://localhost:${server.address().port}`;
  let cookie = '';
  let failed = 0;

  for (const [method, path, body, expected, label] of checks) {
    const headers = {};
    if (cookie) headers.cookie = cookie;
    const options = { method, headers };
    if (body) {
      headers['content-type'] = 'application/json';
      options.body = JSON.stringify(body);
    }
    const res = await fetch(base + path, options);
    const set = res.headers.getSetCookie();
    if (set.length) cookie = set.map((c) => c.split(';')[0]).join('; ');
    await res.text();
    const ok = res.status === expected;
    if (!ok) failed++;
    console.log(`${ok ? 'OK  ' : 'FAIL'} ${method} ${path} -> ${res.status} (очікувалось ${expected}) — ${label}`);
  }

  console.log(failed ? `\nПровалено: ${failed}` : '\nУсі перевірки пройдено');
  server.close();
  process.exit(failed ? 1 : 0);
});
