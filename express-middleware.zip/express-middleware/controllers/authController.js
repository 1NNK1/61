const User = require('../models/userModel');

exports.login = (req, res, next) => {
  const found = User.findByCredentials(req.body.username, req.body.password);
  if (!found) {
    return res.status(401).send('Невірний логін або пароль');
  }
  req.session.regenerate((err) => {
    if (err) return next(err);
    req.session.user = { id: found.id, username: found.username, role: found.role };
    res.send(`Вхід виконано: ${found.username}`);
  });
};

exports.logout = (req, res, next) => {
  req.session.destroy((err) => {
    if (err) return next(err);
    res.clearCookie('sid');
    res.send('Вихід виконано');
  });
};
