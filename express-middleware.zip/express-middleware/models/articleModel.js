const articles = [
  { id: 1, title: 'Вступ до Express.js', authorId: 2, visibility: 'public', content: 'Express — мінімалістичний веб-фреймворк для Node.js.' },
  { id: 2, title: 'Мідлвари в Express', authorId: 3, visibility: 'public', content: 'Мідлвар — функція, яка обробляє запит до того, як він потрапить у маршрут.' },
  { id: 3, title: 'Внутрішні нотатки адміністратора', authorId: 1, visibility: 'private', content: 'Закрита стаття, доступна лише адміністратору.' },
  { id: 4, title: 'Чернетка про сесії', authorId: 2, visibility: 'private', content: 'Приватна стаття, доступна автору та адміністратору.' }
];

const canView = (article, user) => {
  if (article.visibility === 'public') return true;
  if (!user) return false;
  return user.role === 'admin' || article.authorId === user.id;
};

const findById = (id) => articles.find((a) => a.id === id);
const findVisible = (user) => articles.filter((a) => canView(a, user));

module.exports = { canView, findById, findVisible };
