const Article = require('../models/articleModel');
const view = require('../views/textView');

exports.list = (req, res) => {
  res.send(view.articleList(Article.findVisible(req.session.user)));
};

exports.details = (req, res) => {
  res.send(view.article(req.article));
};
