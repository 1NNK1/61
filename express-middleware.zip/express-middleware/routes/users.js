const express = require('express');
const users = require('../controllers/userController');
const requireAuth = require('../middleware/auth');
const { validateId, validateListQuery } = require('../middleware/validate');

const router = express.Router();

router.use(requireAuth);

router.get('/', validateListQuery, users.list);
router.get('/:userId', validateId('userId'), users.details);

module.exports = router;
