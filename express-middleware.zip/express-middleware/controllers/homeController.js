const view = require('../views/textView');

exports.index = (req, res) => {
  res.send(view.home(req.session.user));
};
